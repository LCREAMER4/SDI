/*
Lara Creamer
SDI 1505
Lab 2
Fun With Data
 */

//These are my variables
var myVacation = "December 31";
var vacationPlanning = " a cruise to \" The Bahamas \"";
var myFamily = 4;
var weather = true;

//myoutputs

console.log("My vacation this year is " + myVacation + ".");
console.log("I am planning " + vacationPlanning  +".");
console.log("I will be planning a vacation for my family of " + myFamily + ".");
console.log("It is snowing today. "+ weather + ".");

//confirm();
raining=confirm ("Is it snowing today? Click OK for yes, cancel for no.");

var prompt = prompt("Time for vacation");